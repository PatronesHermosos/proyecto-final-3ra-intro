 
 //negacion
 var x1vel = 9
 var y1vel = 9
 var x1pos = 460
 var y1pos = 220
 var negacion = document.getElementById('negacion');
 
 setInterval(function(){
   if(x1pos>1010 || x1pos<460) {
     x1vel = -1*x1vel;
   }
   if(y1pos>525 || y1pos<220) {
     y1vel = -1*y1vel;
   }
 
 x1pos = x1pos + x1vel;
 y1pos = y1pos + y1vel;
 negacion.style.left = x1pos + 'px';
 negacion.style.top = y1pos + 'px'; 
 },100);


 //panico
var x2vel = 8
var y2vel = 8
var x2pos = 460
var y2pos = 220
var panico = document.getElementById('panico');

setInterval(function(){
 if(x2pos>1010 || x2pos<460) {
   x2vel = -1*x2vel;
 }
 if(y2pos>525 || y2pos<220) {
   y2vel = -1*y2vel;
 }

x2pos = x2pos + x2vel;
y2pos = y2pos + y2vel;
panico.style.left = x2pos + 'px';
panico.style.top = y2pos + 'px'; 
},100);


//adaptacion
var x3vel = 10
var y3vel = 10
var x3pos = 460
var y3pos = 220
var adaptacion = document.getElementById('adaptacion');

setInterval(function(){
 if(x3pos>1010 || x3pos<460) {
   x3vel = -1*x3vel;
 }
 if(y3pos>525 || y3pos<220) {
   y3vel = -1*y3vel;
 }

x3pos = x3pos + x3vel;
y3pos = y3pos + y3vel;
adaptacion.style.left = x3pos + 'px';
adaptacion.style.top = y3pos + 'px'; 
},100);


//desesperacion
var x4vel = 12
var y4vel = 12
var x4pos = 460
var y4pos = 220
var desesperacion = document.getElementById('desesperacion');

setInterval(function(){
 if(x4pos>1010 || x4pos<460) {
   x4vel = -1*x4vel;
 }
 if(y4pos>525 || y4pos<220) {
   y4vel = -1*y4vel;
 }

x4pos = x4pos + x4vel;
y4pos = y4pos + y4vel;
desesperacion.style.left = x4pos + 'px';
desesperacion.style.top = y4pos + 'px'; 
},100);


//normalizacion
var x5vel = 11
var y5vel = 11
var x5pos = 460
var y5pos = 220
var normalizacion = document.getElementById('normalizacion');

setInterval(function(){
 if(x5pos>1010 || x5pos<460) {
   x5vel = -1*x5vel;
 }
 if(y5pos>525 || y5pos<220) {
   y5vel = -1*y5vel;
 }

x5pos = x5pos + x5vel;
y5pos = y5pos + y5vel;
normalizacion.style.left = x5pos + 'px';
normalizacion.style.top = y5pos + 'px'; 
},100);


//esperanza
var x6vel = 13
var y6vel = 13
var x6pos = 460
var y6pos = 220
var esperanza = document.getElementById('esperanza');

setInterval(function(){
 if(x6pos>1010 || x6pos<460) {
   x6vel = -1*x6vel;
 }
 if(y6pos>525 || y6pos<220) {
   y6vel = -1*y6vel;
 }

x6pos = x6pos + x6vel;
y6pos = y6pos + y6vel;
esperanza.style.left = x6pos + 'px';
esperanza.style.top = y6pos + 'px'; 
},100);